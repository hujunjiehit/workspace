require "TSLib"

function goBack(...)
	tap(26,84);
	mSleep(1000);
end

function pull_the_screen(x,y,dy)
	moveTo(x,y,x,y+dy,10,200)
end


function do_the_work(begin)
	-- body
	for index = begin,7 do
		y = 407 + 154*(index-1);
		tap(416,407 + 143*(index-1));
		mSleep(1000);
		goBack();
	end
end

function main(...)
	-- body
	init("0", 0);  --竖屏
	initLog("脚本宣传记录", 0);	--把 0 换成 1 即生成形似 test_1397679553.log 的日志文件 
	wLog("脚本宣传记录","\n\n\n\n脚本开始时间:"..os.date("%c")); 
	
	showFloatButton(false);
	
	width,height = getScreenSize();
	nLog("[DATE]"..width.."---"..height);
	
	do_the_work(1);
	pull_the_screen(320,560,-308)
	mSleep(2000)
	do_the_work(3);
		mSleep(2000)
		pull_the_screen(320,560,-308)
		mSleep(2000)
		do_the_work(3);
	showFloatButton(true);
	closeLog("脚本宣传记录");  --关闭日志
end

main()